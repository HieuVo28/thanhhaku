import json
from lib import defaults

def ensure():
    """
    create default settings.json if it does not exist
    """
    if not defaults.SETTINGS_FILE.is_file():
        with open(defaults.SETTINGS_FILE, 'w') as f:
            json.dump(defaults.SETTINGS, f)
    print("Settings file created")

def draw_page(selectables):
    """
    draw the settings page
    """
    print("Settings:")
    for i, selectable in enumerate(selectables):
        print("{}. {}".format(i + 1, selectable))
    while True:
        # get user input
        try:
            input_ = int(input("Select: "))
            #validate input
            if input_ < 0 or input_ > len(selectables):
                print("Invalid input")
                continue
            # return the selected item
            return selectables[input_ - 1]
        except ValueError:
            print("Invalid input")
            continue
if __name__ == "__main__":
    ensure()
    print("Settings Editor")
    
    while True:
        selection = draw_page([
            "Configure",
            "Exit"
        ])

        if selection == "Exit":
            break
        elif selection == "Configure":
            print("Configure")

            ##FOR EACH DİCTIONARY IN THE SETTINGS DICTIONARY 
            ##CREATE A NEW PAGE
            ##IF ITEM ISN'T DICTIONARY
            ##DRAW IT İN THE PAGE

