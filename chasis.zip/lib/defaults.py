SETTINGS_FILE = 'settings.json'
SETTINGS = {
        "account": {
            "username": "",
            "password": "",
        },
        "service": {
            "status": "off/on",
            "engine": "1,2,3"
        },
        "automation_settings": {
            "humanization": {
                "enabled": False,
                "interval": "1",
                "time": "1",
                "volume": "1",
                "read_full_desc": {
                    "enabled": False,
                    "0-100 charracters": 0.10,
                    "100-200 charracters": 0.40,
                    "200+ charracters": 0.60,
                }
            }
        }
}
